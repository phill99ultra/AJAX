import React from "react";
import ReactDOM from "react-dom";
import LikeButton from "./likebutton";
import LanguageSelector from "./LanguageSelector";
import Check from "./Check";

import "./styles.css";

function App() {
  return (
    <div className="App">
      {/* <LikeButton label="I like this post"/>
      <LikeButton label="I like this comment"/>
      <LanguageSelector/> */}
      <Check label="I agree with your english"/>
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
