// modulul unei componente
import React, { Component } from "react";
class LikeButton extends Component {
  constructor(props) {
    super();
    this.state = {
      likes: 0,
      enabled: true
    };
  }
  click = () => {
    this.setState({
      likes: this.state.likes + 1
    });
    if (this.state.likes >= 2) this.disable();
  };
  disable = () => {
    this.setState({
      enabled: false
    });
  };
  render() {
    return (
      <button onClick={this.click} disabled={!this.state.enabled}>
        {this.props.label} {this.state.likes}
      </button>
    );
  }
}

export default LikeButton;
