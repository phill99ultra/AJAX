import React, { Component } from "react";
class LanguageSelector extends Component {
  // constructor(props) {

  // }
  
  render() {
    const languages = ["en", "rus", "rom"];
    let language = languages.map(d => <option>{d}</option>
      );
      return <select>{language}</select>;
    }
  }
    export default LanguageSelector;
