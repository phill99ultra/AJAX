import React from 'react'
import './Button.css' 

class Button extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            disabled : this.props.disabled
        }
        this.text = this.props.text;
    }
    render(){
        let styles = {}        
        if (this.props.type == "danger") {
            styles = {
                backgroundColor : "red"
            }
        }
        return <button className="my-button" disabled={this.state.disabled} style={styles}>
                    {this.text}
                </button>
    }
}

export default Button