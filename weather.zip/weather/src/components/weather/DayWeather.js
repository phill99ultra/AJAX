import React, {Component} from 'react';
import './DayWeather.sass'
import WeatherService from './Weather'




class DayWeather extends Component{
    constructor() {
        super();
        this.state = {
            data: WeatherService.getWeatherData()
        }
    }
    
    render() {
        let {date, icon, temp} = this.state.data;
        return <div className='day--weather'>
            <img src={icon} alt=""/>
            <h3>Thu ({date})</h3>
            <p>{temp} C</p>
        </div>
    }
}

export default DayWeather;
