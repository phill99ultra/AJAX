import axios from 'axios'
const KEY = '1d1cc8cb74b544a1225842686d140ea4';
const URL = `https://api.openweathermap.org/data/2.5/weather?q=London,uk&appid=${KEY}`;

class Day{
    constructor(date, icon, temp) {
        this.date = date;
        this.icon = icon;
        this.temp = temp;
    }
}
class WeatherService{
    static getWeatherData() {
        axios.get(URL)
            .then(response => {
                console.log(response);
                let d = new Day("", "", response.data.main.temp)
            })
        return new Day("01-01-2019", "1.png", 20);
    }
}
export default WeatherService